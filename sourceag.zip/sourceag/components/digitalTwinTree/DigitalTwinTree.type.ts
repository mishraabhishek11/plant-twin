type ID = {
  id: string;
};

type Coordinate = { x: number; y: number };

export type Fruit = ID & {
  development_state: string;
};

export type Child = ID & {
  level: number;
  children: Child[];
  fruits: Fruit[];
};

export type Stem = {
  child: Child;
  position: {
    top: Coordinate;
    firstControlPoint: Coordinate;
    secondControlPoint: Coordinate;
    bottom: Coordinate;
  };
  fruit: {
    fruit: Fruit | undefined;
    position: Coordinate;
    rotate: boolean;
  };
};
