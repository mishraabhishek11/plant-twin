import { Child } from "./DigitalTwinTree.type";

/**
 *
 *
 * @param {Child} member
 * @return {*}
 */
export const hasChildren = (member: Child) => {
  return member ? member.children && member.children.length > 0 : false;
};

/**
 *
 *
 * @param {Child} item
 * @return {*}
 */
export const isMainStem = (item: Child) => {
  return item ? `${item.level}` === "1" || `${item.level}` === "0" : false;
};

/**
 *
 *
 * @param {Child} item
 * @return {*}
 */
export const isBranchStem = (item: Child) => {
  return item ? `${item.level}` === "2" : false;
};

/**
 *
 *
 * @param {Child} item
 * @return {*}
 */
export const itemMainStemChildrens = (item: Child) => {
  return item && item.children && item.children.length > 0
    ? [...item.children].filter((child) => {
        return `${child.level}` === "1";
      })
    : [];
};

/**
 *
 *
 * @param {Child} item
 * @return {*}
 */
export const itemBranchStemChildrens = (item: Child) => {
  return item && item.children && item.children.length > 0
    ? [...item.children].filter((child) => {
        return `${child.level}` === "2";
      })
    : [];
};

/**
 *
 *
 * @param {number} value
 * @param {number} stemCoverHeight
 * @param {number} valueReverse
 * @return {*}
 */
export const revertY = (
  value: number,
  stemCoverHeight: number,
  valueReverse: number,
  windowHight: number
) => {
  return windowHight - value + stemCoverHeight * valueReverse;
};

/**
 *
 *
 * @param {number} stemTopX
 * @param {number} stemTopY
 * @param {number} stemBottomX
 * @param {number} stemBottomY
 * @param {number} stemCoverHeight
 * @param {number} stemCurvWidth
 * @return {*}
 */
export const getMainStemControlPoints = (
  stemTopX: number,
  stemTopY: number,
  stemBottomX: number,
  stemBottomY: number,
  stemCoverHeight: number,
  stemCurvWidth: number
) => {
  const stemFirstCPX: number = stemTopX + (stemCurvWidth / 10) * 2;
  const stemFirstCPY: number = stemTopY + (stemCoverHeight / 10) * 4;

  const stemSecondCPX: number = stemBottomX - (stemCurvWidth / 10) * 2;
  const stemSecondCPY: number = stemTopY + (stemCoverHeight / 10) * 8;

  return {
    first: { x: stemFirstCPX, y: stemFirstCPY },
    second: { x: stemSecondCPX, y: stemSecondCPY },
  };
};

export const getBranchStemControlPoints = (
  branchBottomX: number,
  branchBottomY: number,
  stemLengthX: number,
  stemLengthY: number,
  branchSideWeight: number
) => {
  const stemFirstCPX: number =
    branchBottomX + (stemLengthX / 10) * 4 * branchSideWeight;
  const stemFirstCPY: number = branchBottomY - (stemLengthY / 10) * 6;

  const stemSecondCPX: number =
    branchBottomX + (stemLengthX / 10) * 6 * branchSideWeight;
  const stemSecondCPY: number = branchBottomY - (stemLengthY / 10) * 4;
  return {
    first: { x: stemFirstCPX, y: stemFirstCPY },
    second: { x: stemSecondCPX, y: stemSecondCPY },
  };
};
