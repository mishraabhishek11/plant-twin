import { FruitStage } from "@/constants/FruitStage";
import HarvestableFruit from "../images/harvestableFruit";
import MatureGreenFruit from "../images/matureGreenFruit";
import BreakerStageFruit from "../images/breakerStageFruit";
import BudFruit from "../images/budFruit";
import FlowerFruit from "../images/flowerFruit";
import SetFruit from "../images/setFruit";

const FruitStageImage = (props: {
  fruitDevelopmentState: string;
  rotate: boolean;
}) => {
  const { fruitDevelopmentState, rotate } = props;

  const rotateStyle = {
    transform: [{ rotateY: rotate ? "180deg" : "0deg" }],
  };

  /**
   *
   *
   * @param {string[]} stages
   * @return {*}
   */
  const isStage = (stages: string[]) => {
    return stages.indexOf(fruitDevelopmentState) > -1;
  };
  return (
    <>
      {isStage([FruitStage.HARVESTABLE, FruitStage.HARVESTABLE_FRUIT]) ? (
        <HarvestableFruit style={rotateStyle} />
      ) : null}
      {isStage([FruitStage.BREAKER_STAGE, FruitStage.BREAKER_STAGE_FRUIT]) ? (
        <BreakerStageFruit style={rotateStyle} />
      ) : null}
      {isStage([FruitStage.MATURE_GREEN, FruitStage.MATURE_GREEN_FRUIT]) ? (
        <MatureGreenFruit style={rotateStyle} />
      ) : null}
      {isStage([FruitStage.BUD, FruitStage.BUD_FRUIT]) ? (
        <BudFruit style={rotateStyle} />
      ) : null}
      {isStage([FruitStage.FLOWER_FRUIT, FruitStage.FLOWER]) ? (
        <FlowerFruit style={rotateStyle} />
      ) : null}
      {isStage([FruitStage.SET, FruitStage.SET_FRUIT]) ? (
        <SetFruit style={rotateStyle} />
      ) : null}
    </>
  );
};

export default FruitStageImage;
