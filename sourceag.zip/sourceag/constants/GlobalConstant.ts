export const stemID = "7b02aa08-5f06-4ac5-ae2b-fb582a2e8372"; // "9ac45c32-64f1-4a27-b554-e3544cbbe001";

export const mainStemHeight = 150;
export const mainStemCurvWidth = 10;

export const branchStemExpansionX = 60;
export const branchStemExpansionY = 110;

export const stemNodeRadius = 15;
